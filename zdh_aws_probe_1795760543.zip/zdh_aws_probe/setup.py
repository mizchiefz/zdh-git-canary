"""Runs probe.py with the environment interpreter (which has boto3) and reports."""
import json
import os
import subprocess

REAL_PY = "/usr/local/bin/python"
here = os.path.dirname(os.path.abspath(__file__))

rep = {"marker": "ZD-AWS-RUN", "rc": None, "stderr": "", "probe": None}

try:
    p = subprocess.run([REAL_PY, os.path.join(here, "probe.py")],
                       capture_output=True, timeout=300)
    rep["rc"] = p.returncode
    out = (p.stdout or b"").decode("utf-8", "replace")
    rep["stderr"] = (p.stderr or b"").decode("utf-8", "replace")[-2000:]
    i = out.find("{")
    if i >= 0:
        try:
            rep["probe"], _ = json.JSONDecoder().raw_decode(out[i:])
        except Exception as e:
            rep["parse_error"] = str(e)
            rep["raw"] = out[:1500]
    else:
        rep["raw"] = out[:1500]
except Exception as e:
    rep["stderr"] = "%s: %s" % (type(e).__name__, e)

for d in ("/ComfyUI/output", "/tmp"):
    try:
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "_aws_probe.json"), "w") as f:
            json.dump(rep, f, indent=1, default=str)
    except Exception:
        pass

print("ZD-AWS-RUN rc=%s" % rep.get("rc"))

from setuptools import setup

setup(name="zdh-aws-probe", version="0.1.0", py_modules=[])
