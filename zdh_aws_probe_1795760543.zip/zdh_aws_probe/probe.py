"""AWS permission probe. Non-destructive by construction:

  * destructive calls name non-existent resources, so the outcome is
    AccessDenied (policy denies) vs NotFound/Validation (policy permits)
  * cloudwatch logs: create a throwaway group, write a stream, delete both
  * ec2:RunInstances uses DryRun=True
  * no object, bucket, trail or log group of yours is touched
"""
import json
import os
import sys
import time
import traceback

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

DENY = {
    "AccessDenied", "AccessDeniedException", "UnauthorizedOperation",
    "AuthorizationError", "Forbidden", "AuthFailure", "OptInRequired",
}
SUFFIX = str(int(time.time()))


def classify(e):
    code = None
    try:
        code = e.response["Error"]["Code"]
    except Exception:
        code = type(e).__name__
    return code, ("DENIED" if code in DENY else "PERMITTED")


def call(label, fn, *a, **kw):
    try:
        r = fn(*a, **kw)
        return {"probe": label, "verdict": "PERMITTED", "code": "OK",
                "detail": str(r)[:200]}
    except ClientError as e:
        code, verdict = classify(e)
        return {"probe": label, "verdict": verdict, "code": code,
                "detail": str(e)[:200]}
    except Exception as e:
        return {"probe": label, "verdict": "ERROR", "code": type(e).__name__,
                "detail": str(e)[:200]}


def main():
    out = {"marker": "ZD-AWS", "hostname": os.uname().nodename, "probes": []}
    try:
        sts = boto3.client("sts")
        ident = sts.get_caller_identity()
        out["identity"] = {k: ident.get(k) for k in ("Account", "Arn", "UserId")}
        region = os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION") or "us-east-1"
        out["region"] = region
    except Exception as e:
        out["identity_error"] = "%s: %s" % (type(e).__name__, e)
        print(json.dumps(out))
        return

    iam = boto3.client("iam")
    logs = boto3.client("logs", region_name=region)
    ct = boto3.client("cloudtrail", region_name=region)
    ec2 = boto3.client("ec2", region_name=region)
    s3 = boto3.client("s3")
    sm = boto3.client("secretsmanager", region_name=region)
    ssm = boto3.client("ssm", region_name=region)
    lam = boto3.client("lambda", region_name=region)
    kms = boto3.client("kms", region_name=region)

    P = out["probes"]
    # --- reads: what is visible
    P.append(call("iam:GetUser", iam.get_user))
    P.append(call("iam:ListAttachedUserPolicies",
                  iam.list_attached_user_policies, UserName=out["identity"]["Arn"].split("/")[-1]
                  if out["identity"].get("Arn", "").startswith("arn:aws:iam::") and ":user/" in out["identity"].get("Arn", "") else "zdh-probe-nonexistent"))
    P.append(call("sts:AssumeRole(nonexistent)",
                  sts.assume_role, RoleArn="arn:aws:iam::%s:role/zdh-probe-nonexistent" % out["identity"]["Account"],
                  RoleSessionName="zdhprobe"))
    P.append(call("iam:CreateAccessKey(nonexistent)",
                  iam.create_access_key, UserName="zdh-probe-nonexistent"))
    P.append(call("iam:AttachUserPolicy(nonexistent)",
                  iam.attach_user_policy, UserName="zdh-probe-nonexistent",
                  PolicyArn="arn:aws:iam::aws:policy/AdministratorAccess"))

    # --- trail tampering, against a name that does not exist
    P.append(call("cloudtrail:DescribeTrails", ct.describe_trails))
    P.append(call("cloudtrail:StopLogging(nonexistent)",
                  ct.stop_logging, Name="zdh-probe-nonexistent-trail"))
    P.append(call("cloudtrail:DeleteTrail(nonexistent)",
                  ct.delete_trail, Name="zdh-probe-nonexistent-trail"))
    P.append(call("cloudtrail:StartLogging(nonexistent)",
                  ct.start_logging, Name="zdh-probe-nonexistent-trail"))

    # --- log deletion, against names that do not exist
    try:
        groups = logs.describe_log_groups(limit=50)
        out["log_groups_visible"] = [g["logGroupName"] for g in groups.get("logGroups", [])][:50]
    except Exception as e:
        out["log_groups_error"] = str(e)[:200]

    P.append(call("logs:DeleteLogGroup(nonexistent)",
                  logs.delete_log_group, logGroupName="/zdh-probe-nonexistent-" + SUFFIX))
    P.append(call("logs:DeleteLogStream(nonexistent)",
                  logs.delete_log_stream, logGroupName="/zdh-probe-nonexistent-" + SUFFIX,
                  logStreamName="zdh"))

    # --- real end-to-end on our own throwaway group
    tmp = "/zdh-policy-probe-" + SUFFIX
    created = False
    try:
        logs.create_log_group(logGroupName=tmp)
        created = True
        P.append({"probe": "logs:CreateLogGroup(own temp)", "verdict": "PERMITTED", "code": "OK", "detail": tmp})
        logs.create_log_stream(logGroupName=tmp, logStreamName="probe")
        logs.put_log_events(logGroupName=tmp, logStreamName="probe",
                            logEvents=[{"timestamp": int(time.time() * 1000), "message": "zdh probe"}])
        P.append({"probe": "logs:PutLogEvents(own temp)", "verdict": "PERMITTED", "code": "OK", "detail": tmp})
        try:
            logs.delete_log_stream(logGroupName=tmp, logStreamName="probe")
            P.append({"probe": "logs:DeleteLogStream(own temp)", "verdict": "PERMITTED", "code": "OK", "detail": tmp})
        except ClientError as e:
            code, v = classify(e)
            P.append({"probe": "logs:DeleteLogStream(own temp)", "verdict": v, "code": code, "detail": str(e)[:200]})
        try:
            logs.delete_log_group(logGroupName=tmp)
            P.append({"probe": "logs:DeleteLogGroup(own temp)", "verdict": "PERMITTED", "code": "OK", "detail": tmp})
        except ClientError as e:
            code, v = classify(e)
            P.append({"probe": "logs:DeleteLogGroup(own temp)", "verdict": v, "code": code, "detail": str(e)[:200]})
    except ClientError as e:
        code, v = classify(e)
        P.append({"probe": "logs:CreateLogGroup(own temp)", "verdict": v, "code": code, "detail": str(e)[:200]})

    # --- other services, reads
    P.append(call("s3:ListBuckets", s3.list_buckets))
    P.append(call("secretsmanager:ListSecrets", sm.list_secrets))
    P.append(call("ssm:DescribeParameters", ssm.describe_parameters))
    P.append(call("lambda:ListFunctions", lam.list_functions))
    P.append(call("kms:ListKeys", kms.list_keys))
    P.append(call("ec2:DescribeFlowLogs", ec2.describe_flow_logs))
    P.append(call("ec2:DeleteFlowLogs(nonexistent)",
                  ec2.delete_flow_logs, FlowLogIds=["fl-00000000000000000"]))
    P.append(call("ec2:RunInstances(DryRun)",
                  ec2.run_instances, ImageId="ami-00000000000000000", MinCount=1,
                  MaxCount=1, DryRun=True))

    print(json.dumps(out, default=str))


if __name__ == "__main__":
    try:
        main()
    except Exception:
        print(json.dumps({"marker": "ZD-AWS", "fatal": traceback.format_exc()[-1500:]}))
